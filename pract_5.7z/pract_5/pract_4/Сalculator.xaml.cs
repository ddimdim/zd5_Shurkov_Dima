﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace pract_4
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Сalculator :ContentPage
    {
        public Сalculator ()
        {
            InitializeComponent();
        }
        private void SliderValueChange (object sender, ValueChangedEventArgs e)
        {
            try
            {
                
                if (LoanEntry.Text != null && MonthEntry.Text != null && PaymentTypePicker.Items.ToString() != null)
                {
                    Calculation(LoanEntry.Text, MonthEntry.Text, PaymentTypePicker.SelectedIndex, Slider.Value);
                    
                }
                else
                {
                    MonthlyPaymentLabel.Text = "Ежемесячный платеж: 0";
                    TotalLabel.Text = "Общая сумма: 0";
                    OverpaymentLabel.Text = "Переплата: 0";
                    if (Slider.Value != 20)
                    {
                        DisplayAlert("Ошибка", "Введите все необходимые данные", "Ок");
                    }
                }
                SliderLabel.Text = $"{Slider.Value}%";

            }
            catch
            {
                DisplayAlert("Ошибка", "Можно вводить только цифры", "Ок");
            }
            
        }

        private void Calculation (string credit, string creditMonths, int picker, double percent)
        {

            if (Convert.ToDouble(credit) > 0 && Convert.ToDouble(creditMonths) > 0 && picker != -1)
            {
                    double month = percent / 1200;
                    double annuity = month * Math.Pow(1 + month, int.Parse(creditMonths)) / (Math.Pow(1 + month, int.Parse(creditMonths)) - 1);
                    double payment = Math.Round(double.Parse(credit) * annuity, 2);
                    MonthlyPaymentLabel.Text = $"Ежемесячный платеж: {payment}";
                    TotalLabel.Text = $"Общая сумма: {Math.Round(payment, 2) * int.Parse(creditMonths)}";
                    OverpaymentLabel.Text = $"Переплата: {Math.Round(Math.Round(payment, 2) * int.Parse(creditMonths) - Math.Round(double.Parse(credit), 2), 2)}";
                    if (picker != 0)
                    {
                        MonthlyPaymentLabel.Text = $"Ежемесячный платеж:";
                    }

            } else if (Convert.ToDouble(credit) < 0 || Convert.ToDouble(creditMonths) < 0)
            {
                DisplayAlert("Ошибка", "Введите все значения корректно", "Ок");
            }
            else
                {
                    MonthlyPaymentLabel.Text = "Ежемесячный платеж: 0";
                    TotalLabel.Text = "Общая сумма: 0";
                    OverpaymentLabel.Text = "Переплата: 0";
                    
                }
             
        }
    }
}